const readAndDeleteLine = require('./readAndDeleteLine')

module.exports = {
    readAndDeleteLine
};