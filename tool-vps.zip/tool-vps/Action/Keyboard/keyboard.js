const pressKey = require('../Keyboard/pressKey');

const keyboard = {
    pressKey
}
module.exports = keyboard;