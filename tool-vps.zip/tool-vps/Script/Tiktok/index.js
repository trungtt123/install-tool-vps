const viewTikTok_1 = require('./ViewTiktok/viewTikTok_1');
const tiktok = {
    viewTikTok_1
}
module.exports = tiktok;