const yahooSearch_1 = require('./YahooSearch/yahooSearch_1');
const yahoo = {
    yahooSearch_1,
}
module.exports = yahoo;