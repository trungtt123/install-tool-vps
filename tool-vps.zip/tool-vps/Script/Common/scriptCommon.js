const getRandomPositionOfRandomVisibleElement = require('./getRandomPositionOfRandomVisibleElement');
const scriptCommon = {
    getRandomPositionOfRandomVisibleElement
}
module.exports = scriptCommon;