const loginFacebook_1 = require('./LoginFacebook/loginFacebook_1');
const facebook = {
    loginFacebook_1
}
module.exports = facebook;