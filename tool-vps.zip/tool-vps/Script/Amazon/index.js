const viewAmazon_1 = require('./Amazon_1/viewAmazon_1');
const amazon = {
    viewAmazon_1
}
module.exports = amazon;