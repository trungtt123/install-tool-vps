const buffMC = require('./Buff/buffMC')
const another = {
    buffMC
}
module.exports = another;