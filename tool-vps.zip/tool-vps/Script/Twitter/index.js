const viewTwitter_1 = require('./ViewTwitter/viewTwitter_1');
const twitter = {
    viewTwitter_1
}
module.exports = twitter;