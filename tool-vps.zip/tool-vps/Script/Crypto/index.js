const cosmicwire_1 = require('./Cosmicwire/cosmicwire_1');
const grvt = require('./GRVT/grvt');
const crypto = {
    cosmicwire_1,
    grvt
}
module.exports = crypto;