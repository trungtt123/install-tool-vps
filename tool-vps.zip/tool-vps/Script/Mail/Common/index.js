const viotp = require('./viotp');
const reportDisableMail = require('./reportDisableMail');
module.exports = {
    viotp,
    reportDisableMail
}